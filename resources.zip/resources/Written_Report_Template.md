# Kickstarting with Excel

## Overview of Project
    This is a large dataset of a fundrasing campaign that contains various elements such as different types of shows, fundraising goals, lunch date, and end date. 
### Purpose
    The purpose of this project is to help Louise to analyze the campaign outcome based her goal, date, and funding raised. 

## Analysis and Challenges
    This dataset includes various factors, which may that be relevant to her purposes. The challenge of this analysis is to narrow down relevant information that better suits her needs. 

### Analysis of Outcomes Based on Launch Date
    In most cases, success incidents are higher than failed incidents. 

### Analysis of Outcomes Based on Goals
    the sample size dramatically decreases as fundraising goal reaches above 10000. The highest success rate is when the goal is less than 1000. 

### Challenges and Difficulties Encountered

## Results

- What are two conclusions you can draw about the Outcomes based on Launch Date?
    The highest number of success is in the summer and lowest in the winter. 

- What can you conclude about the Outcomes based on Goals?
    The number of projects and success rate are higher when goal is below 5000. The number of total projects is highest with goal ranges from 1000 to 4999 (534). The highest sucess rate is with goal less than 1000 (76%). 

- What are some limitations of this dataset?
    some data are in different currency. A conversion of currency should be done before comparing their values. 

- What are some other possible tables and/or graphs that we could create?
    We could sort by country and currency. 